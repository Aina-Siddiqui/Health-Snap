import { initializeApp, getApps } from 'firebase/app';
import { getAuth, setPersistence, getReactNativePersistence } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getDatabase } from 'firebase/database';

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB9mN7prPcObUlCor6H56pH1GSgKsCcLTU",
  authDomain: "doctor-app-91aad.firebaseapp.com",
  databaseURL: 'https://doctor-app-91aad-default-rtdb.firebaseio.com/',
  projectId: "doctor-app-91aad",
  storageBucket: "doctor-app-91aad.appspot.com",
  messagingSenderId: "988537859032",
  appId: "1:988537859032:web:3d2f6a5f946fff947560ad",
  measurementId: "G-Z4PGG3L5ZJ"
};

// Initialize Firebase only if it hasn't been initialized yet
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

// Initialize Firebase Authentication
const auth = getAuth(app);

// Set persistence for authentication (local persistence using AsyncStorage)
setPersistence(auth, getReactNativePersistence(AsyncStorage))
  .then(() => {
    console.log("Persistence set to local.");
  })
  .catch((error) => {
    console.error("Error setting persistence:", error);
  });

// Initialize Realtime Database
const db = getDatabase(app);

export { auth, db };
