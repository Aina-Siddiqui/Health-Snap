// constants/fonts.js
import {
    OpenSans_400Regular,
    OpenSans_300Light,
    OpenSans_500Medium,
    OpenSans_700Bold,
    useFonts,
  } from '@expo-google-fonts/open-sans';
  
  export {
    OpenSans_400Regular,
    OpenSans_300Light,
    OpenSans_500Medium,
    OpenSans_700Bold,
    useFonts,
  };
  