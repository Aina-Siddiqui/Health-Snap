import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { NavigationIndependentTree } from '@react-navigation/core';
import HomeTabNavigator from '../components/navigation/TabNavigator';
import StackNavigator from '../components/navigation/StackNavigator';
import { StripeProvider } from '@stripe/stripe-react-native';
// Example of another navigator

export default function Index() {
  return (
    <StripeProvider publishableKey="pk_test_51PS2oKDoqVnrQcFeuZY6uDg3ByFr6sSNmZIK0YKTW5s3UgqcnoxT6ieB49LDkToyKS4FWZgqenmBEBMYbyNWCatj00KcVFVLVU">
      <NavigationIndependentTree>
        <StackNavigator />
      </NavigationIndependentTree>
    </StripeProvider>

  );
}
