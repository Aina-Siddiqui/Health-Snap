const pageImages = [
  {
    id: "1",
    name: "Appointment",
    image: require("../../assets/images/Appointment.png"),
  },
];

export default pageImages;
