const meetings = [
  {
    id: "1",
    label: "Voice Call",
  },
  {
    id: "2",
    label: "Video Conference",
  },
  {
    id: "3",
    label: "At Hospital",
  },
];

export default meetings;
